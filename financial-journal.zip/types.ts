export interface FinancialRecord {
  id: string;
  date: string; // Storing date as YYYY-MM-DD string
  depositPoints: number;
  transactionPoints: number;
  projectCount: number;
  income: number;
  expense: number;
}