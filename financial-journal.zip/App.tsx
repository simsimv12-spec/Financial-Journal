import React, { useState } from 'react';
import { FinancialRecord } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import FinancialRecordForm from './components/FinancialRecordForm';
import FinancialRecordList from './components/FinancialRecordList';
import SummaryView from './components/SummaryView';
import Modal from './components/Modal';

const App: React.FC = () => {
    const [records, setRecords] = useLocalStorage<FinancialRecord[]>('financialRecords', []);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [recordToEdit, setRecordToEdit] = useState<FinancialRecord | null>(null);

    const openEditModal = (record: FinancialRecord) => {
        setRecordToEdit(record);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setRecordToEdit(null);
    };

    const handleAddRecord = (record: Omit<FinancialRecord, 'id'>) => {
        const newRecord: FinancialRecord = {
            id: new Date().toISOString() + Math.random().toString(36),
            ...record,
        };
        setRecords([...records, newRecord].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    };

    const handleUpdateRecord = (updatedRecord: FinancialRecord) => {
        setRecords(
            records.map((r) => (r.id === updatedRecord.id ? updatedRecord : r))
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        );
        closeModal();
    };

    const handleDeleteRecord = (id: string) => {
        if (window.confirm('이 기록을 정말 삭제하시겠습니까?')) {
            setRecords(records.filter((r) => r.id !== id));
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 font-sans">
            <header className="bg-white dark:bg-gray-800 shadow-md">
                <div className="container mx-auto px-4 py-6">
                    <h1 className="text-3xl font-bold text-center text-indigo-600 dark:text-indigo-400">
                        재정 기록 일지
                    </h1>
                </div>
            </header>

            <main className="container mx-auto px-4 py-8">
                <SummaryView records={records} />

                <div className="mt-8 grid grid-cols-1 xl:grid-cols-5 gap-8 items-start">
                    <div className="sticky top-8 xl:col-span-2">
                        <FinancialRecordForm
                            onAdd={handleAddRecord}
                            recordToEdit={null}
                        />
                    </div>

                    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg xl:col-span-3">
                        <h2 className="text-2xl font-semibold mb-6">거래 내역</h2>
                        <FinancialRecordList
                            records={records}
                            onEdit={openEditModal}
                            onDelete={handleDeleteRecord}
                        />
                    </div>
                </div>
            </main>

            <Modal isOpen={isModalOpen} onClose={closeModal}>
                {recordToEdit && (
                    <FinancialRecordForm
                        onClose={closeModal}
                        onUpdate={handleUpdateRecord}
                        recordToEdit={recordToEdit}
                    />
                )}
            </Modal>
        </div>
    );
};

export default App;