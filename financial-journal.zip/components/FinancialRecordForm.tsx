import React, { useState, useEffect } from 'react';
import { FinancialRecord } from '../types';

interface FinancialRecordFormProps {
    onClose?: () => void;
    onAdd?: (record: Omit<FinancialRecord, 'id' | 'project'> & { projectCount: number }) => void;
    onUpdate?: (record: FinancialRecord) => void;
    recordToEdit: FinancialRecord | null;
}

const FinancialRecordForm: React.FC<FinancialRecordFormProps> = ({ onClose, onAdd, onUpdate, recordToEdit }) => {
    const getInitialState = () => ({
        date: new Date().toISOString().split('T')[0],
        depositPoints: '',
        transactionPoints: '',
        projectCount: '',
        income: '',
        expense: '',
    });
    
    const [formData, setFormData] = useState(getInitialState());

    useEffect(() => {
        if (recordToEdit) {
            setFormData({
                date: recordToEdit.date,
                depositPoints: String(recordToEdit.depositPoints),
                transactionPoints: String(recordToEdit.transactionPoints),
                projectCount: String(recordToEdit.projectCount),
                income: String(recordToEdit.income),
                expense: String(recordToEdit.expense),
            });
        } else {
            setFormData(getInitialState());
        }
    }, [recordToEdit]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        const submissionData = {
            date: formData.date,
            depositPoints: Number(formData.depositPoints) || 0,
            transactionPoints: Number(formData.transactionPoints) || 0,
            projectCount: Number(formData.projectCount) || 0,
            income: Number(formData.income) || 0,
            expense: Number(formData.expense) || 0,
        };

        if (recordToEdit && onUpdate) {
            onUpdate({ ...submissionData, id: recordToEdit.id });
        } else if (onAdd) {
            onAdd(submissionData);
            setFormData(getInitialState()); // Reset form after adding
        }
    };
    
    const handleCancel = () => {
        if (recordToEdit && onClose) {
            onClose();
        } else {
            setFormData(getInitialState()); // Reset form in add mode
        }
    };

    const inputClasses = "w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-gray-200";

    return (
        <div className="bg-white dark:bg-gray-800 p-8 rounded-xl w-full shadow-lg">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 dark:text-gray-100">
                {recordToEdit ? '기록 수정' : '새 기록 추가'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">날짜</label>
                    <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} className={inputClasses} required />
                </div>
                <div>
                    <label htmlFor="projectCount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">참여프로젝트 (개수)</label>
                    <input type="number" id="projectCount" name="projectCount" value={formData.projectCount} onChange={handleChange} className={inputClasses} placeholder="예: 5" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="income" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">수입 (USD)</label>
                        <input type="number" id="income" name="income" value={formData.income} onChange={handleChange} className={inputClasses} />
                    </div>
                    <div>
                        <label htmlFor="expense" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">지출 (USD)</label>
                        <input type="number" id="expense" name="expense" value={formData.expense} onChange={handleChange} className={inputClasses} />
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="depositPoints" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">예치포인트</label>
                        <input type="number" id="depositPoints" name="depositPoints" value={formData.depositPoints} onChange={handleChange} className={inputClasses} />
                    </div>
                    <div>
                        <label htmlFor="transactionPoints" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">거래포인트</label>
                        <input type="number" id="transactionPoints" name="transactionPoints" value={formData.transactionPoints} onChange={handleChange} className={inputClasses} />
                    </div>
                </div>
                <div className="flex justify-end pt-6 space-x-3">
                    <button type="button" onClick={handleCancel} className="py-2 px-4 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors">
                        {recordToEdit ? '취소' : '초기화'}
                    </button>
                    <button type="submit" className="py-2 px-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                        {recordToEdit ? '업데이트' : '저장'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default FinancialRecordForm;