import React from 'react';
import { FinancialRecord } from '../types';
import { EditIcon, TrashIcon } from './Icons';

interface FinancialRecordListProps {
    records: FinancialRecord[];
    onEdit: (record: FinancialRecord) => void;
    onDelete: (id: string) => void;
}

const USD_TO_KRW_RATE = 1450;

const FinancialRecordList: React.FC<FinancialRecordListProps> = ({ records, onEdit, onDelete }) => {
    if (records.length === 0) {
        return (
            <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                <p className="text-lg">기록이 없습니다.</p>
                <p>양식을 사용하여 새 기록을 추가하세요.</p>
            </div>
        );
    }
    
    const formatToKRW = (amount: number) => {
        return (amount * USD_TO_KRW_RATE).toLocaleString('ko-KR', {
            style: 'currency',
            currency: 'KRW',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        });
    };

    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" className="px-6 py-3 whitespace-nowrap">날짜</th>
                        <th scope="col" className="px-6 py-3 whitespace-nowrap">프로젝트(개수)</th>
                        <th scope="col" className="px-6 py-3 text-right whitespace-nowrap">수입</th>
                        <th scope="col" className="px-6 py-3 text-right whitespace-nowrap">지출</th>
                        <th scope="col" className="px-6 py-3 text-right whitespace-nowrap">예치포인트</th>
                        <th scope="col" className="px-6 py-3 text-right whitespace-nowrap">거래포인트</th>
                        <th scope="col" className="px-6 py-3 text-center whitespace-nowrap">관리</th>
                    </tr>
                </thead>
                <tbody>
                    {records.map(record => (
                        <tr key={record.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                {record.date}
                            </td>
                            <td className="px-6 py-4 text-right">{record.projectCount}</td>
                            <td className="px-6 py-4 text-right text-green-600 dark:text-green-400 whitespace-nowrap">{formatToKRW(record.income)}</td>
                            <td className="px-6 py-4 text-right text-red-600 dark:text-red-400 whitespace-nowrap">{formatToKRW(record.expense)}</td>
                            <td className="px-6 py-4 text-right">{record.depositPoints.toLocaleString()}</td>
                            <td className="px-6 py-4 text-right">{record.transactionPoints.toLocaleString()}</td>
                            <td className="px-6 py-4 text-center whitespace-nowrap">
                                <button onClick={() => onEdit(record)} className="p-2 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300" aria-label="기록 수정">
                                    <EditIcon className="w-5 h-5" />
                                </button>
                                <button onClick={() => onDelete(record.id)} className="p-2 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 ml-2" aria-label="기록 삭제">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default FinancialRecordList;