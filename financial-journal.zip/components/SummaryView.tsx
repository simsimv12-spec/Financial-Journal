// FIX: Import 'useEffect' from 'react' to resolve reference error.
import React, { useState, useMemo, useEffect } from 'react';
import { FinancialRecord } from '../types';

interface SummaryViewProps {
    records: FinancialRecord[];
}

const USD_TO_KRW_RATE = 1450;

const SummaryView: React.FC<SummaryViewProps> = ({ records }) => {
    const today = new Date();
    const [selectedYear, setSelectedYear] = useState(today.getFullYear());
    const [selectedMonth, setSelectedMonth] = useState(today.getMonth() + 1);

    const { years, months } = useMemo(() => {
        const yearSet = new Set<number>();
        const monthSet = new Set<number>();
        records.forEach(r => {
            const d = new Date(r.date);
            yearSet.add(d.getFullYear());
        });
        
        // Populate months based on records for the selected year
        records.forEach(r => {
            const d = new Date(r.date);
            if (d.getFullYear() === selectedYear) {
                monthSet.add(d.getMonth() + 1);
            }
        });

        if (yearSet.size === 0) yearSet.add(today.getFullYear());
        const sortedYears = Array.from(yearSet).sort((a, b) => b - a);

        if (monthSet.size === 0) monthSet.add(today.getMonth() + 1);
        const sortedMonths = Array.from(monthSet).sort((a, b) => a - b);

        return {
            years: sortedYears,
            months: sortedMonths
        };
    }, [records, selectedYear]);

     // Effect to reset month if it's not available in the new year
     useEffect(() => {
        if (selectedMonth !== 0 && !months.includes(selectedMonth)) {
            setSelectedMonth(months[months.length -1] || today.getMonth() + 1);
        }
    }, [selectedYear, months, selectedMonth, today]);


    const filteredRecords = useMemo(() => {
        return records.filter(record => {
            const recordDate = new Date(record.date);
            if (selectedMonth === 0) { // "All months" selected
                return recordDate.getFullYear() === selectedYear;
            }
            return recordDate.getFullYear() === selectedYear && (recordDate.getMonth() + 1) === selectedMonth;
        });
    }, [records, selectedYear, selectedMonth]);

    const summary = useMemo(() => {
        return filteredRecords.reduce((acc, record) => {
            acc.totalIncome += record.income;
            acc.totalExpense += record.expense;
            acc.totalDepositPoints += record.depositPoints;
            acc.totalTransactionPoints += record.transactionPoints;
            return acc;
        }, {
            totalIncome: 0,
            totalExpense: 0,
            totalDepositPoints: 0,
            totalTransactionPoints: 0
        });
    }, [filteredRecords]);
    
    const netTotal = summary.totalIncome - summary.totalExpense;
    const totalPoints = summary.totalDepositPoints + summary.totalTransactionPoints;
    
    const formatToKRW = (amount: number) => {
       return (amount * USD_TO_KRW_RATE).toLocaleString('ko-KR', {
         style: 'currency',
         currency: 'KRW',
         minimumFractionDigits: 0,
         maximumFractionDigits: 0,
       });
    };

    const selectClasses = "bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5";

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-semibold">요약</h2>
                <div className="flex gap-4">
                    <select value={selectedYear} onChange={(e) => setSelectedYear(parseInt(e.target.value))} className={selectClasses}>
                        {years.map(year => <option key={year} value={year}>{year}년</option>)}
                    </select>
                    <select value={selectedMonth} onChange={(e) => setSelectedMonth(parseInt(e.target.value))} className={selectClasses}>
                        <option value={0}>전체월</option>
                        {months.map(month => <option key={month} value={month}>{month}월</option>)}
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-center">
                <SummaryCard title="총 수입" value={formatToKRW(summary.totalIncome)} color="text-green-500" />
                <SummaryCard title="총 지출" value={formatToKRW(summary.totalExpense)} color="text-red-500" />
                <SummaryCard title="순이익" value={formatToKRW(netTotal)} color={netTotal >= 0 ? 'text-blue-500' : 'text-red-500'} />
                <SummaryCard title="총 예치포인트" value={summary.totalDepositPoints.toLocaleString()} color="text-purple-500" />
                <SummaryCard title="총 거래포인트" value={summary.totalTransactionPoints.toLocaleString()} color="text-yellow-500" />
                <SummaryCard title="총 포인트" value={totalPoints.toLocaleString()} color="text-indigo-500" />
            </div>
            <p className="text-xs text-gray-400 dark:text-gray-500 text-right mt-4">
                * 수입/지출은 USD 입력 기준이며, KRW로 자동 환산됩니다. (적용환율: 1$ = {USD_TO_KRW_RATE.toLocaleString()}원)
            </p>
        </div>
    );
};

interface SummaryCardProps {
    title: string;
    value: string;
    color: string;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, color }) => (
    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
        <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
        <p className={`text-2xl font-bold ${color}`}>{value}</p>
    </div>
);


export default SummaryView;